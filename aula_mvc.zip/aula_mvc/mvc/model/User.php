<?php
require_once 'DB.php';

	class User{
		public function authenticate($user, $pass){
			$conn = DB::connect();

			$stmt = $conn->prepare("SELECT * from users where username = ? and password = MD5(?)");
			$stmt->bind_param("ss",$user,$pass);
			$stmt->execute();

			$result = $stmt->get_result();
			return $result->num_rows > 0;
		}
	}
?>