<?
	class DB {
		public static function connect(){
			$host	= "localhost";
			$user 	= "root";
			$pass 	= "";
			$dbname = "mvc_db";

			$conn = new mysqli($host, $user, $pass, $dbname);
			if ($conn->connect_error)
			{
				die("Erro de conexão:". $conn->connect_error);
			}

			return $conn;
		}
	}
?>