

create table USERS( 
id int AUTO_INCREMENT PRIMARY key, 
username varchar(50) not null unique, 
password varchar(255) not null );

insert into users(username, password) values ('thiagao',md5('thiago'));