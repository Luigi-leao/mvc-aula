<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Login</title>
</head>
<body>
	<?php if(!empty($error)) echo "<p style='color:red;'>$error</p>"; ?>
	<form method="POST" action="">
		<input type="text" name="username" placeholder="Usuário" required><br>
		<input type="password" name="password" placeholder="Senha" required><br>
		<button type="submit">Entrar</button>
	</form>
</body>
</html>