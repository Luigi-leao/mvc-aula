<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Bem vindo ao sistema</title>
</head>
<body>
	<h2>Login realizado com sucesso!</h2>
</body>
</html>