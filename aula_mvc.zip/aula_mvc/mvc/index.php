<?php
	require_once 'controller/AuthController.php';

	$controller = new AuthController();

	if ($_SERVER['REQUEST_METHOD'] === 'POST'){
		$controller->login($_POST);
	}else
	{
		$controller->loginform();
	}
?>